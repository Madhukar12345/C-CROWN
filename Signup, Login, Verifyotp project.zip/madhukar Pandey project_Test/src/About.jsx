import React from 'react'

export default function About() {
  return (
    <>
    <h1> Welcome About Page</h1>
    </>
  )
}
