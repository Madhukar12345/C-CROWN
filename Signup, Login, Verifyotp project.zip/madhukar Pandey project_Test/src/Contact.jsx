import React from 'react'

export default function Contact() {
  return (
    <>
    <h1> Welcome Contact Page</h1>
    </>
  )
}
