import React from 'react'

export default function Service() {
  return (
    <>
    <h1> Welcome Service Page</h1>
    </>
  )
}
