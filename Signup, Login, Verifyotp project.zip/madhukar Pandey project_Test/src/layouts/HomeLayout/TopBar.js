import React from 'react'

const TopBar = () => {
  return (
    <div>TopBar</div>
  )
}

export default TopBar