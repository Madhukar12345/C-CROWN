import React from 'react'
import Home from "./routes/Home"
import About from "./routes/About"
import Contact from "./routes/Contact"
import Project from "./routes/Project"
import Signup from './Components/Signup'
import Login from './Components/Login'


export default function App() {
  return (
    <>
   <Signup/>
   
    </>
)}
